
module register #(parameter WIDTH = 32) (
	input 	wire 	[WIDTH-1:0]	d_in,			// Data input
	input 	wire 	 			sclr, 		// Synchronous clear input
	input 	wire 	 			ld, 		// Load input
	input 	wire 	 			clk, 		// Clock input signal
	output 	reg 	[WIDTH-1:0]	q			// Data output
);

	always @(posedge clk)
	begin
		if (sclr)
			q <= 0;
		else if (ld)
			q <= d_in;
	end

endmodule


module counter #(parameter WIDTH = 32) (                                                                                            
	input 	wire 	[WIDTH-1:0]	 	d_in, 		// Data input
	input 	wire 	 				ld, 		// Load input
	input 	wire 	 				ce, 		// Count enable
	input 	wire 	 				clk,		// Clock input signal
	output 	reg 	[WIDTH-1:0]		q			// Data output
);
	// localparam WIDTH = $clog2((n+1)/2+ 1);

	always @(posedge clk)
	begin
		// $display ("-->%d", q);
		if (ld)
			q <= d_in;
		else if(ce)
		begin
			q <= q - 1;			
		end
	end

endmodule 


module mux_2_to_1 #(parameter WIDTH = 32) (
	input 	wire 	[WIDTH-1:0]	i0, 		// I0 input
	input 	wire 	[WIDTH-1:0]	i1, 		// I1 input
	input 	wire 	 			sel, 		// Sel input
	output 	wire 	[WIDTH-1:0]	y			// Multiplexer output
);

	assign y = sel ? i1 : i0;

endmodule

module mux_3_to_1 #(parameter WIDTH = 32) (
    input  wire [WIDTH-1:0] i0,     // Input 0 (e.g., 0)
    input  wire [WIDTH-1:0] i1,     // Input 1 (e.g., Y)
    input  wire [WIDTH-1:0] i2,     // Input 2 (e.g., 2Y)
    input  wire [1:0]       sel,    // 2-bit Select input
    output wire [WIDTH-1:0] y       // Multiplexer output
);

    // Continuous assignment using nested ternary operators
    assign y = (sel == 2'b10) ? i2 :
               (sel == 2'b01) ? i1 : 
                                i0; // Default to i0 when sel is 2'b00 (or 2'b11)

endmodule
module q_sel_structural (
    input  wire [2:0] divisor_idx, 
    input  wire [6:0] y_hat,       
    output wire [2:0] q_next       
);

    // --- STAGE 1: SIGN SPLIT & INVERSION ---
    wire is_neg = y_hat[6];
    wire is_pos = ~y_hat[6];
    
    // Invert the magnitude bits (w = ~y_hat)
    wire [5:0] w = ~y_hat[5:0];

    // --- STAGE 2: THRESHOLD GENERATION ---
    
    // Positive Thresholds: y >= m
    wire p_geq_4  = y_hat[5] | y_hat[4] | y_hat[3] | y_hat[2];
    wire p_geq_6  = y_hat[5] | y_hat[4] | y_hat[3] | (y_hat[2] & y_hat[1]);
    wire p_geq_8  = y_hat[5] | y_hat[4] | y_hat[3];
    wire p_geq_12 = y_hat[5] | y_hat[4] | (y_hat[3] & y_hat[2]);
    wire p_geq_14 = y_hat[5] | y_hat[4] | (y_hat[3] & y_hat[2] & y_hat[1]);
    wire p_geq_15 = y_hat[5] | y_hat[4] | (y_hat[3] & y_hat[2] & y_hat[1] & y_hat[0]);
    wire p_geq_16 = y_hat[5] | y_hat[4]; 
    wire p_geq_18 = y_hat[5] | (y_hat[4] & (y_hat[3] | y_hat[2] | y_hat[1]));
    wire p_geq_20 = y_hat[5] | (y_hat[4] & (y_hat[3] | y_hat[2]));
    wire p_geq_24 = y_hat[5] | (y_hat[4] & y_hat[3]);

    // Negative Thresholds: y < m  =>  y <= m - 1  =>  w >= -m
    wire n_leq_m5  = w[5] | w[4] | w[3] | w[2];                               // w >= 4
    wire n_leq_m7  = w[5] | w[4] | w[3] | (w[2] & w[1]);                      // w >= 6
    wire n_leq_m9  = w[5] | w[4] | w[3];                                      // w >= 8
    wire n_leq_m14 = w[5] | w[4] | (w[3] & w[2] & (w[1] | w[0]));             // w >= 13
    wire n_leq_m16 = w[5] | w[4] | (w[3] & w[2] & w[1] & w[0]);               // w >= 15
    wire n_leq_m17 = w[5] | w[4];                                             // w >= 16
    wire n_leq_m19 = w[5] | (w[4] & (w[3] | w[2] | w[1]));                    // w >= 18
    wire n_leq_m21 = w[5] | (w[4] & (w[3] | w[2]));                           // w >= 20
    wire n_leq_m23 = w[5] | (w[4] & (w[3] | (w[2] & w[1])));                  // w >= 22
    wire n_leq_m25 = w[5] | (w[4] & w[3]);                                    // w >= 24

    // --- STAGE 3: PRIORITY DECODING PER BRANCH ---
    wire [2:0] b8, b9, b10, b11, b12, b13, b14, b15;

    // Branch 8: +12, +4  |  -13, -4  =>  y <= -14, y <= -5
    assign b8[2] = is_neg;
    assign b8[1] = (is_pos & p_geq_12) | (is_neg & n_leq_m14);
    assign b8[0] = (is_pos & p_geq_4 & ~p_geq_12) | (is_neg & n_leq_m5 & ~n_leq_m14);

    // Branch 9: +14, +4  |  -15, -6  =>  y <= -16, y <= -7
    assign b9[2] = is_neg;
    assign b9[1] = (is_pos & p_geq_14) | (is_neg & n_leq_m16);
    assign b9[0] = (is_pos & p_geq_4 & ~p_geq_14) | (is_neg & n_leq_m7 & ~n_leq_m16);

    // Branch 10: +15, +4  |  -16, -6  =>  y <= -17, y <= -7
    assign b10[2] = is_neg;
    assign b10[1] = (is_pos & p_geq_15) | (is_neg & n_leq_m17);
    assign b10[0] = (is_pos & p_geq_4 & ~p_geq_15) | (is_neg & n_leq_m7 & ~n_leq_m17);

    // Branch 11: +16, +4  |  -18, -6  =>  y <= -19, y <= -7
    assign b11[2] = is_neg;
    assign b11[1] = (is_pos & p_geq_16) | (is_neg & n_leq_m19);
    assign b11[0] = (is_pos & p_geq_4 & ~p_geq_16) | (is_neg & n_leq_m7 & ~n_leq_m19);

    // Branch 12: +18, +6  |  -20, -8  =>  y <= -21, y <= -9
    assign b12[2] = is_neg;
    assign b12[1] = (is_pos & p_geq_18) | (is_neg & n_leq_m21);
    assign b12[0] = (is_pos & p_geq_6 & ~p_geq_18) | (is_neg & n_leq_m9 & ~n_leq_m21);

    // Branch 13: +20, +6  |  -20, -8  =>  y <= -21, y <= -9
    assign b13[2] = is_neg;
    assign b13[1] = (is_pos & p_geq_20) | (is_neg & n_leq_m21);
    assign b13[0] = (is_pos & p_geq_6 & ~p_geq_20) | (is_neg & n_leq_m9 & ~n_leq_m21);

    // Branch 14: +20, +8  |  -22, -8  =>  y <= -23, y <= -9
    assign b14[2] = is_neg;
    assign b14[1] = (is_pos & p_geq_20) | (is_neg & n_leq_m23);
    assign b14[0] = (is_pos & p_geq_8 & ~p_geq_20) | (is_neg & n_leq_m9 & ~n_leq_m23);

    // Branch 15: +24, +8  |  -24, -8  =>  y <= -25, y <= -9
    assign b15[2] = is_neg;
    assign b15[1] = (is_pos & p_geq_24) | (is_neg & n_leq_m25);
    assign b15[0] = (is_pos & p_geq_8 & ~p_geq_24) | (is_neg & n_leq_m9 & ~n_leq_m25);

    // --- STAGE 4: THE STATIC 8-TO-1 MUX ---
    assign q_next = (divisor_idx == 3'b000) ? b8  :
                    (divisor_idx == 3'b001) ? b9  :
                    (divisor_idx == 3'b010) ? b10 :
                    (divisor_idx == 3'b011) ? b11 :
                    (divisor_idx == 3'b100) ? b12 :
                    (divisor_idx == 3'b101) ? b13 :
                    (divisor_idx == 3'b110) ? b14 :
                                              b15 ;

endmodule

module adder #(parameter WIDTH = 32) (
	input 	wire 	[WIDTH-1:0]	a, 		// A input
	input 	wire 	[WIDTH-1:0]	b, 		// B input
	input 	wire 				ci, 	// Carry input
	output 	wire 				co, 	// Carry output
	output 	wire 	[WIDTH-1:0]	s 		// Sum output
);

	assign {co, s} = a + b + ci;

endmodule




module csa #(parameter WIDTH = 32) (
	input 	wire 	[WIDTH-1:0]	a, 		// A input
	input 	wire 	[WIDTH-1:0]	b, 		// B input
	input 	wire 	[WIDTH-1:0]	c, 		// C input
	output 	wire 	[WIDTH-1:0]	sv, 	// Sum vector output
	output 	wire 	[WIDTH-1:0]	cv 		// Carry vector output
);	

	assign sv  = a ^ b ^ c;
	assign cv = ((a & b) | (a & c) | (b & c));

endmodule
 




module add_sub_csa #(parameter WIDTH = 32) (
    input  wire [WIDTH-1:0] wc_in,      
    input  wire [WIDTH-1:0] ws_in,      
    input  wire [WIDTH-1:0] mux_in,     
    input  wire             op_sign,    
    
    output wire [WIDTH-1:0] wc_out,     
    output wire [WIDTH-1:0] ws_out      
);

    reg [WIDTH-1:0] operand;

    always @(*) begin
        if (op_sign == 1'b0) begin
            operand = mux_in;
        end else begin
            operand = ~mux_in;
        end
    end

    wire [WIDTH-1:0] csa_cv;
    csa #(WIDTH) internal_csa (
        .a(wc_in),
        .b(ws_in),
        .c(operand),
        .sv(ws_out),    
        .cv(csa_cv)     
    );

    assign wc_out = {csa_cv[WIDTH-2:0], op_sign};

endmodule

module termination_block #(parameter WIDTH = 32) (
    input  wire [WIDTH+2:0] wc_final,
    input  wire [WIDTH+2:0] ws_final,
    input  wire [WIDTH-1:0] divisor,
    
    output wire [WIDTH-1:0] true_rem,
    output wire             rem_sign
);

    wire [WIDTH+2:0] raw_rem_35;
    
    adder #(WIDTH+3) assimilation_cpa (
        .a(wc_final),
        .b(ws_final),
        .ci(1'b0),
        .co(),
        .s(raw_rem_35)
    );

    assign rem_sign = raw_rem_35[WIDTH+2];

    wire [WIDTH-1:0] restored_rem;
    
    adder #(WIDTH) correction_adder (
        .a(raw_rem_35[WIDTH-1:0]),
        .b(divisor),
        .ci(1'b0),
        .co(),
        .s(restored_rem)
    );

    assign true_rem = (rem_sign) ? restored_rem : raw_rem_35[WIDTH-1:0];

endmodule

module otfc_block #(parameter WIDTH = 32) (
    input  wire             clk,
    input  wire             clr,        // Clear to 0 at the start of division
    input  wire             en,         // Enable shift (active during the 16 iterations)
    input  wire [2:0]       q_next,     // Output from q_sel_block: {Sign, Mag[1:0]}
    
    output reg  [WIDTH-1:0] Q,          // The main quotient register
    output reg  [WIDTH-1:0] QM          // The quotient-minus-one register
);

    reg [WIDTH-1:0] next_Q;
    reg [WIDTH-1:0] next_QM;

    // Combinational logic to determine the next state based on the Radix-4 digit
    always @(*) begin
        case (q_next)
            // POSITIVE DIGITS (Base is Q)
            3'b010: begin // q = +2
                next_Q  = {Q[WIDTH-3:0], 2'b10};    // Append 2
                next_QM = {Q[WIDTH-3:0], 2'b01};    // Append 1
            end
            3'b001: begin // q = +1
                next_Q  = {Q[WIDTH-3:0], 2'b01};    // Append 1
                next_QM = {Q[WIDTH-3:0], 2'b00};    // Append 0
            end
            
            // ZERO (Splits the base)
            3'b000, 3'b100: begin // q = 0 (Handles both positive and negative zero)
                next_Q  = {Q[WIDTH-3:0],  2'b00};   // Base Q, Append 0
                next_QM = {QM[WIDTH-3:0], 2'b11};   // Base QM, Append 3 (which acts as a borrow)
            end
            
            // NEGATIVE DIGITS (Base is QM)
            3'b101: begin // q = -1
                next_Q  = {QM[WIDTH-3:0], 2'b11};   // Append 3
                next_QM = {QM[WIDTH-3:0], 2'b10};   // Append 2
            end
            3'b110: begin // q = -2
                next_Q  = {QM[WIDTH-3:0], 2'b10};   // Append 2
                next_QM = {QM[WIDTH-3:0], 2'b01};   // Append 1
            end
            
            default: begin
                next_Q  = Q;
                next_QM = QM;
            end
        endcase
    end

    // Sequential logic to update the registers on the clock edge
    always @(posedge clk) begin
        if (clr) begin
            Q  <= 0;
            QM <= 0;
        end else if (en) begin
            Q  <= next_Q;
            QM <= next_QM;
        end
    end

endmodule