
`timescale 1ns / 1ps

module r4_div_top #(parameter WIDTH = 32) (
    input  wire                 clk,
    input  wire                 rst,
    input  wire                 start,
    input  wire [WIDTH-1:0]     x_norm,
    input  wire [WIDTH-1:0]     y_norm,
    
    output wire [WIDTH-1:0]     q_out,
    output wire [WIDTH-1:0]     rem_out,
    output wire                 done
);

    // Interconnect Control & Status Signals
    wire ld_d;
    wire init_loop;
    wire en_regs;
    wire clr_otfc;
    wire en_otfc;
    wire ld_itr_cnt;
    wire dec_itr_cnt;
    wire end_of_iterations;

    // Instantiate Controller (FSM)
    r4_div_controller CONTROLLER (
        .clk(clk),
        .rst(rst),
        .start(start),
        .end_of_iterations(end_of_iterations),
        .ld_d(ld_d),
        .init_loop(init_loop),
        .en_regs(en_regs),
        .clr_otfc(clr_otfc),
        .en_otfc(en_otfc),
        .ld_itr_cnt(ld_itr_cnt),
        .dec_itr_cnt(dec_itr_cnt),
        .done(done)
    );

    // Instantiate Datapath
    r4_div_datapath #(WIDTH) DATAPATH (
        .clk(clk),
        .x_norm(x_norm),
        .y_norm(y_norm),
        .ld_d(ld_d),
        .init_loop(init_loop),
        .en_regs(en_regs),
        .clr_otfc(clr_otfc),
        .en_otfc(en_otfc),
        .ld_itr_cnt(ld_itr_cnt),
        .dec_itr_cnt(dec_itr_cnt),
        .end_of_iterations(end_of_iterations),
        .q_out(q_out),
        .rem_out(rem_out)
    );

endmodule