import random

NUM_TESTS = 10000
filename = "vectors.txt"

with open(filename, "w") as f:
    for _ in range(NUM_TESTS):
        # Generate normalized Y (0.5 to ~1.0) -> MSB must be 1
        y = random.randint(0x80000000, 0xFFFFFFFF)
        # Generate X such that X < Y
        x = random.randint(0x00000000, y - 1) >> 1
        
        # Calculate standard integer quotient and remainder
        # Since X < Y, standard integer division is just 0.
        # But for fractional division, we shift X by 32 bits.
        x_shifted = x << 32
        q = x_shifted // y
        r = (x_shifted % y)  # Scale remainder back down
        
        # Write as hex strings: X Y Expected_Q Expected_R
        # Format: X Y Q R (No spaces, one solid 128-bit string)
        f.write(f"{x:08x}{y:08x}{q:08x}{r:08x}\n")

print(f"Generated {NUM_TESTS} test vectors in {filename}")