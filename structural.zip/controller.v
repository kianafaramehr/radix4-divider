
module r4_div_controller (
    input  wire clk,
    input  wire rst,                // Synchronous or asynchronous reset
    input  wire start,              // Signal to begin division
    input  wire end_of_iterations,  // Status signal from datapath counter

    // Control Signals to Datapath
    output reg  ld_d,
    output reg  init_loop,
    output reg  en_regs,
    output reg  clr_otfc,
    output reg  en_otfc,
    output reg  ld_itr_cnt,
    output reg  dec_itr_cnt,
    
    // Status Signal to CPU/Environment
    output reg  done
);

    // State Encoding
    localparam [2:0] 
        IDLE   = 3'b000,
        INIT   = 3'b001,
        DIVIDE = 3'b010,
        TER    = 3'b011,
        DONE   = 3'b100;

    reg [2:0] current_state, next_state;

    // =========================================================================
    // Block 1: State Memory (Sequential)
    // =========================================================================
    always @(posedge clk) begin
        if (rst) begin
            current_state <= IDLE;
        end else begin
            current_state <= next_state;
        end
    end

    // =========================================================================
    // Block 2: Next State Logic (Combinational)
    // =========================================================================
    always @(*) begin
        
        next_state = current_state; 

        case (current_state)
            IDLE: begin
                if (start) 
                    next_state = INIT;
            end
            
            INIT: begin
                next_state = DIVIDE;
            end
            
            DIVIDE: begin
                if (end_of_iterations) 
                    next_state = TER;
            end
            
            TER: begin
                next_state = DONE;
            end
            
            DONE: begin
                if (!start) // Wait for start to de-assert before returning to IDLE
                    next_state = IDLE;
            end
            
            default: next_state = IDLE;
        endcase
    end

    // =========================================================================
    // Block 3: Output Logic (Combinational)
    // =========================================================================
    always @(*) begin
        
        ld_d        = 1'b0;
        init_loop   = 1'b0;
        en_regs     = 1'b0;
        clr_otfc    = 1'b0;
        en_otfc     = 1'b0;
        ld_itr_cnt  = 1'b0;
        dec_itr_cnt = 1'b0;
        done        = 1'b0;

        case (current_state)
            IDLE: begin
                // Waiting for instructions; no outputs active
            end
            
            INIT: begin
                ld_d       = 1'b1; // Load the divisor Y
                init_loop  = 1'b1; // Route initial X and 0 into the WC/WS registers
                en_regs    = 1'b1; // Enable loading of WC/WS
                clr_otfc   = 1'b1; // Clear Q and QM to zero
                ld_itr_cnt = 1'b1; // Load the iteration counter with N/2
            end
            
            DIVIDE: begin
        	if (!end_of_iterations) begin
            		init_loop   = 1'b0; 
            		en_regs     = 1'b1; 
            		en_otfc     = 1'b1; 
            		dec_itr_cnt = 1'b1; 
        	end
    	     end
            
            TER: begin
                // The termination block is purely combinational, but we give the 
                // datapath this one clock cycle for the final carry-propagate 
                // assimilation to settle cleanly before asserting 'done'.
            end
            
            DONE: begin
                done = 1'b1; // Signal to the main CPU that q_out and rem_out are valid
            end
            
            default: begin
                // Defaults apply
            end
        endcase
    end

endmodule