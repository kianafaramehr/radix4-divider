`timescale 1ns / 1ns

module tb_r4_div_top;

    localparam WIDTH = 32;
    localparam CLK_PERIOD = 10; // 100 MHz clock
    localparam NUM_TESTS = 10000;

    // Inputs
    reg                 clk;
    reg                 rst;
    reg                 start;
    reg  [WIDTH-1:0]    x_norm;
    reg  [WIDTH-1:0]    y_norm;

    // Outputs
    wire [WIDTH-1:0]    q_out;
    wire [WIDTH-1:0]    rem_out;
    wire                done;

    // Automated Testing Variables
    reg [127:0]         test_memory [0:NUM_TESTS-1]; 
    reg [WIDTH-1:0]     expected_q;
    reg [WIDTH-1:0]     expected_r;
    
    integer             i;
    integer             pass_count;
    integer             fail_count;
    real                success_rate;

    // Instantiate Unit Under Test (UUT)
    r4_div_top #(WIDTH) uut (
        .clk(clk),
        .rst(rst),
        .start(start),
        .x_norm(x_norm),
        .y_norm(y_norm),
        .q_out(q_out),
        .rem_out(rem_out),
        .done(done)
    );

    // Clock Generation
    always #(CLK_PERIOD / 2) clk = ~clk;

    // Test Sequence
    initial begin
        // Load the generated test vectors from the Python script
        // Note: Ensure "vectors.txt" is saved in your ModelSim simulation root directory
        $readmemh("vectors.txt", test_memory);
        
        // Initialize score counters
        pass_count = 0;
        fail_count = 0;

        // Initialize Inputs
        clk    = 0;
        rst    = 1;
        start  = 0;
        x_norm = 0;
        y_norm = 0;

        // Apply Reset
        repeat (3) @(posedge clk);
        rst = 0;
        repeat (2) @(posedge clk);

        $display("========================================");
        $display("STARTING AUTOMATED VERIFICATION...");
        $display("========================================");

        // Loop through all 10,000 test vectors
        for (i = 0; i < NUM_TESTS; i = i + 1) begin
            
            // Parse the 128-bit memory line into the four 32-bit segments
            // Format matching the Python script: {X, Y, Expected_Q, Expected_R}
            {x_norm, y_norm, expected_q, expected_r} = test_memory[i];
            
            // Handshake: Pulse the start signal for exactly one clock cycle
            @(posedge clk);
            start = 1'b1;
            @(posedge clk);
            start = 1'b0;
            
            // Wait for the FSM to assert the done flag
            while (!done) begin
                @(posedge clk);
            end
            
            // Verification Check on the exact cycle 'done' is high
            if (q_out === expected_q && rem_out === expected_r) begin
                pass_count = pass_count + 1;
            end else begin
                fail_count = fail_count + 1;
                $display("FAIL at vector %0d: X = 0x%08h, Y = 0x%08h", i, x_norm, y_norm);
                $display("  Expected: Q = 0x%08h, R = 0x%08h", expected_q, expected_r);
                $display("  Got     : Q = 0x%08h, R = 0x%08h", q_out, rem_out);
            end
            
            // Buffer wait before starting the next division to allow FSM to return to IDLE
            repeat(2) @(posedge clk);
        end
        
        // Calculate and display the final grading statistics
        success_rate = (pass_count * 100.0) / NUM_TESTS;
        $display("\n========================================");
        $display("TESTING COMPLETE");
        $display("Passed: %0d", pass_count);
        $display("Failed: %0d", fail_count);
        $display("Success Rate: %0.2f%%", success_rate);
        $display("========================================");
        
        $stop; // Pause the simulation so you can read the ModelSim transcript window
    end

endmodule
